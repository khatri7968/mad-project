import 'package:flutter/material.dart';

const kLightBlue = Color(0xFF77DCF8);
const kLightPink = Color(0xFFF76491);
const kDeepOrange = Colors.deepOrange;
const kLightPurple = Color(0xFF9782FB);
