package com.example.sw32_mad_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
